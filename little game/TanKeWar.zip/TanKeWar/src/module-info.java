module TanKeWar {
	requires java.desktop;
}